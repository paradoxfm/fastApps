#!/bin/bash
CURRENTDIR=`dirname $0`
cd $CURRENTDIR

MEMORY=-Xmx1024m
LOG_PROPERTIES=-Djava.util.logging.config.file=logging.properties

if [ -n "$JAVA_HOME" ]
then
 JAVA="$JAVA_HOME/bin/java"
else
 JAVA=java
fi

$JAVA $LOG_PROPERTIES $MEMORY -jar logview.jar
